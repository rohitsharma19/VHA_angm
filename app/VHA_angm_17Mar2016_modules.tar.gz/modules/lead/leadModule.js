(function () {
	'use strict';

	/**
	 * @ngdoc function
	 * @name app.module:leadModule
	 * @description
	 * # leadModule
	 * Module of the app
	 */

  	angular.module('lead', []);

})();
