(function () {
	'use strict';

	/**
	 * @ngdoc function
	 * @name app.module:opportunityModule
	 * @description
	 * # opportunityModule
	 * Module of the app
	 */

  	angular.module('opportunity', []);

})();
