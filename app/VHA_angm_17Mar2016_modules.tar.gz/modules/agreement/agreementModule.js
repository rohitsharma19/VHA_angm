(function () {
	'use strict';

	/**
	 * @ngdoc function
	 * @name app.module:agreementModule
	 * @description
	 * # agreementModule
	 * Module of the app
	 */

  	angular.module('agreement', []);

})();
