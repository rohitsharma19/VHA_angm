(function () {
	'use strict';

	/**
	 * @ngdoc function
	 * @name app.module:quoteModule
	 * @description
	 * # quoteModule
	 * Module of the app
	 */

  	angular.module('quote', []);

})();
