(function () {
	'use strict';

	/**
	 * @ngdoc function
	 * @name app.module:recommendationModule
	 * @description
	 * # recommendationModule
	 * Module of the app
	 */

  	angular.module('recommendation', []);

})();
